import copy

from GA.individual import *

class population():
    def __init__(self, params, gen_id):
        self.gen_id = gen_id    # 种群当前经历的进化代数
        self.indi_id  = 1       # 种群中最后一个个体编号
        self.pop_size = params["pop_size"]          #  搜索过程中种群数量
        self.guided_size = params["guided_size"]    #  知识引导的初始化个体数目
        self.params = params
        self.individuals = []   # 种群中的个体列表

    def initialize(self):
        """种群初始化
        """
        #  随机初始化
        for _ in range(self.pop_size):
            indi_id = "%02d%02d"%(self.gen_id, self.indi_id)
            indi = Individual(self.params, indi_id)
            indi.initialize_rand()
            self.individuals.append(indi)
            self.indi_id += 1
        
        #  基于知识引导的初始化
        # for _ in range(self.guided_size):
        #     indi_id = "%02d%02d"%(self.gen_id, self.indi_id)
        #     indi = Individual(self.params, indi_id)
        #     indi.initialize_guided()
        #     self.individuals.append(indi)
        #     self.indi_id += 1
    
    def add_offsprings_to_parents(self,offsprings):
        """将生成的子代加入到父代组成新的种群
        """
        for indi_ in offsprings:
            indi=copy.deepcopy(indi_)
            self.individuals.append(indi)
            
    def cal_indi_spantime(self):
        """计算个体的寿命: indi.spantime=n表示indi个体在种群中存活n代, indi.life=n表示indi个体属性值在种群中存在n代
        """
        for indi in self.individuals:
            indi.spantime+=1
            indi.value_life+=1
    
    def updata_indi_id(self):
        """更新种群中的个体编号
        """
        self.indi_id = 1
        for indi in self.individuals:
            indi.id="%02d%02d"%(self.gen_id,self.indi_id)
            self.indi_id += 1
