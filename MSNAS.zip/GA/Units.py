class EncoderUnit():
    def __init__(self, encoder_unit_id, multi_down, Mix_group):
        self.id = encoder_unit_id
        self.multi_down = multi_down
        self.Mix_group = Mix_group
    
    def __str__(self):
        dict = {"encoder_unit_id":self.id, "multi_down":self.multi_down, "MixConv_group":self.Mix_group}
        return str(dict) 

class DecoderUnit():
    def __init__(self, decoder_unit_id, Mix_group, res_AM):
        self.id = decoder_unit_id
        self.Mix_group = Mix_group
        self.res_AM = res_AM
    
    def __str__(self):
        dict = {"decoder_unit_id":self.id, "MixConv_group:":self.Mix_group, "res_AM:":self.res_AM}
        return str(dict) 

