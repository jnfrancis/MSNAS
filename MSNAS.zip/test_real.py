import os
import argparse
import glob
import json


from DIP import config_parser

from DIP.utils.common_utils import *
from DIP.utils.denoising_utils import *
from DIP.utils.denosing_shiyan import *
from DIP.final_arc import *

from config import *

def read_dataset_file_list(eval_data):
    dataset_dir = "./DIP/testset/%s/" % eval_data
    file_list1 = glob.glob(dataset_dir + "*.tif")
    file_list2 = glob.glob(dataset_dir + "*.png")
    file_list3 = glob.glob(dataset_dir + "*.JPG")
    file_list4 = glob.glob(dataset_dir + "*.jpg")
    file_list = file_list1 + file_list2 + file_list3 + file_list4
    return file_list

def save_info(stat, save_path):
    path = './DIP/test_result_1/test4/' + save_path
    with open(path, 'a') as file:
        for key, value in stat.items():
            file.write(f"{key}: {value}\n")
        file.write('\n')

def file_test(args):
    file_list = read_dataset_file_list(args.eval_data)
    file_list = sorted(file_list)
    psnr_list = []
    time_list = []
    stat_dict = {} 

    t_start = time.time()
    stat_dict['info'] = args.path1
    for file in file_list:
        print("[*] process image file : %s"  % file)

        img_psnr_list = []
        img_time_list = []
        for i in range(3):
            psnr, img_time = image_restorazation(file, args)
            img_psnr_list.append(psnr)
            img_time_list.append(img_time)

        good_psnr = max(img_psnr_list)
        good_psnr_index = img_psnr_list.index(good_psnr)
        # 使用找到的索引获取对应的time值
        good_time = img_time_list[good_psnr_index]
        
        base_name = os.path.splitext(os.path.basename(file))[0]
        psnr_name = base_name + '_psnr'
        stat_dict[psnr_name] = good_psnr
        print(f"Image: {base_name}, PSNR: {good_psnr}")

        psnr_list.append(good_psnr)
        time_list.append(good_time)

    average_psnr = sum(psnr_list) / len(psnr_list) if psnr_list else None
    stat_dict['average_PSNR'] = average_psnr

    t_end = time.time()
    t = t_end - t_start

    total_set_time = sum(time_list)  # 计算数据集good_result总耗时
    stat_dict['实验耗时'] = total_set_time

    # 打印或进一步处理平均值
    print(f"Average PSNR value: {average_psnr}")
    save_path =  args.eval_data + '_result.txt'
    save_info(stat_dict, save_path)
    print("experiment done")

    
    print('实验总耗时：', t)
    

def main():
    torch.manual_seed(0)
    np.random.seed(0)

    if torch.cuda.is_available():
        # CUDA可用
        dtype = torch.cuda.FloatTensor  # 在GPU上使用点数
        device = torch.device("cuda:2")  # 指定GPU编号为3
    else:
        raise EnvironmentError("CUDA is not available. Please check your CUDA installation.")
    

    args = config_parser.main_parser()
    args.device = device
    args.task_type = 'denoising'  # 设置子任务为去噪
    args.sigma = 25  # 设置sigma为25
    args.force_steplr = True

    args.dip_type = 'eSURE_uniform'
    args.lr = 0.1

    args.reg_noise_std = 1/20
    args.epoch = 3000

    args.up = params['up_type'][1]
    args.down = params['down_type'][4]
    args.down_concat_list = [1, 0, 0, 1]
    args.skip_concat_list = [0, 0, 1, 0, 1]
    args.res_AM_list = [1, 0, 0, 0, 1]
    args.group_de_list = [1, 1, 2, 1]
    args.group_en_list = [0,0,0,0,0]

    file_list = ['CSet9', 'Set12', 'CBSD68', 'BSD68']
    big_file_list = ['CBSD102', 'BSD102']
    sigma_list = [15, 25, 50, 75, 100]
    big_sigma_list = [75, 100]

    args.net_type = 's2s_multi_skip_mix_de_am'

    for x in range(3):
        # for i in range(2):
        # args.eval_data = big_file_list[i]
        args.eval_data = 'BSD102'
        args.gray = False
        if args.eval_data == 'BSD102':
            args.gray = True
            
        for j in range(2):
            torch.manual_seed(0)
            np.random.seed(0)
            
            args.sigma = sigma_list[j]

            args.path1 = (
                str(args.up) + '_' + str(args.down) + '_multi_down_' +
                ''.join(map(str, args.down_concat_list)) + '_skip_' +
                ''.join(map(str, args.skip_concat_list)) + '_mix_de_' +
                ''.join(map(str, args.group_de_list)) + '_res_am_' +
                ''.join(map(str, args.res_AM_list)) + '--sigma--' + str(args.sigma)
            )

            file_test(args)
    




if __name__ == "__main__":
    main()
# nohup python -u test4.py > test4.log 2>&1 &