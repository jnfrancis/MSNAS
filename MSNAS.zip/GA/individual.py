import numpy as np
import random

class Individual:
    def __init__(self, params, indi_id):
        self.id = indi_id
        self.group_values = params["group_list"]
        self.AM_values = params["AM_list"]
        self.up_num = params["up_num"]
        self.down_num = params["down_num"]
        self.AM_types = params["AM_types"]
        self.up_type = params["up_type"]
        self.down_type = params["down_type"]
        
        #  获取先验精英组合
        self.elite_up = params["elite_up"]
        self.elite_down = params["elite_down"]
        self.elite_multi_down = params["elite_multi_down"]
        self.elite_Mix_group_en = params["elite_Mix_group_en"]
        self.elite_Mix_group_de = params["elite_Mix_group_de"]
        self.elite_res_AM = params["elite_res_AM"]
        self.elite_skip_list = params["elite_skip_list"]


        self.up = 1                 #  网络上采样
        self.down = 0               #  网络下采样
        self.multi_down_list = []   #  多尺度下采样列表
        # self.Mix_group_en = []      #  编码器MixConv各层分组数列表
        self.Mix_group_de = []      #  解码器MixConv各层分组数列表
        self.res_AM = []            #  解码器中的注意力模块列表
        self.skip_list = []         #  固定设计的跳跃连接

        self.gene = []              #  个体架构基因列表
        self.spantime = 0           #  个体在种群中的寿命
        self.value_life = 0         #  个体属性值在种群中的寿命

        self.psnr_avg = 0.0         #  个体输出的指数移动平均获得的PSNR值
        self.psnr_avg_max = 0.0     #  个体训练过程中获得过的峰值
        self.time_train = 0         #  个体结构构建网络后，在指定图片上训练的时间
        
    #  重置个体属性值
    def reset_attrib(self):
        self.psnr_avg = 0.0
        self.psnr_avg_max = 0.0
        self.time_train = 0
        self.spantime = 0
        self.value_life = 0
 
    
    #  随机初始化
    def initialize_rand(self):
        # self.up = random.choice(list(range(self.up_num)))
        self.down = random.choice(list(range(self.down_num)))
        self.multi_down_list = [random.randint(0, 1) for _ in range(4)]
        # self.Mix_group_en = [random.choice(self.group_values) for _ in range(4)]
        self.Mix_group_de = [random.choice(self.group_values) for _ in range(4)]
        self.res_AM = [random.choice(self.AM_values) for _ in range(5)]
        self.skip_list =  [random.randint(0, 1) for _ in range(5)]
        self.update_gene()

    #  基于知识引导的初始化
    def initialize_guided(self):
        pos = np.random.randint(len(self.elite_up))
        self.up = self.elite_up[pos]
        self.down = self.elite_down[pos]
        self.multi_down_list =  self.elite_multi_down[np.random.randint(len(self.elite_multi_down))]
        # self.Mix_group_en =  self.elite_Mix_group_en[np.random.randint(len(self.elite_Mix_group_en))]
        self.Mix_group_de =  self.elite_Mix_group_de[np.random.randint(len(self.elite_Mix_group_de))]
        self.res_AM =  self.elite_res_AM[np.random.randint(len(self.elite_res_AM))]
        self.skip_list =  self.elite_skip_list[np.random.randint(len(self.elite_skip_list))]
        self.update_gene()
    
    #  更新个体基因列表
    def update_gene(self):
        # self.gene = [self.up] + [self.down] + self.multi_down_list + self.Mix_group_en + self.skip_list + self.Mix_group_de + self.res_AM
        # self.gene = [self.up] + [self.down] + self.multi_down_list +  self.skip_list + self.Mix_group_de + self.res_AM
        self.gene = [self.down] + self.multi_down_list +  self.skip_list + self.Mix_group_de + self.res_AM



    def to_dict(self):
        multi_down_str = ''.join(str(bit) for bit in self.multi_down_list)
        skip_str =   ''.join(str(bit) for bit in self.skip_list)
        # mix_group_en_str = ''.join(str(group) for group in self.Mix_group_en) 
        mix_group_de_str = ''.join(str(group) for group in self.Mix_group_de)
        gene_str = ''.join(str(bit) for bit in self.gene)

        first_line = f" 'indi_id': {self.id}, 'psnr_avg': {self.psnr_avg}, 'psnr_avg_max': {self.psnr_avg_max}, 'spantime': {self.spantime}, 'time_train': {self.time_train}, \n"
        #  构建字典内部内容
        dict_content = "{\n"
        dict_content += f"    'indi_gene': '{gene_str}',\n"
        dict_content += f"    'up_sample': '{self.up_type[self.up]}', 'down_sample': '{self.down_type[self.down]}',\n"
        # dict_content += f"    'multi_down': '{multi_down_str}', 'Mix_group_en': '{mix_group_en_str}',\n"
        dict_content += f"    'multi_down': '{multi_down_str}',\n"
        dict_content += f"    'skip_concat': '{skip_str}', 'Mix_group_de': '{mix_group_de_str}', 'AM': {[self.AM_types[r] for r in self.res_AM]},\n"
        dict_content += "}"

        #  个体具体信息
        info = first_line + dict_content

        #  个体整体架构组成
        arc = {
            'indi_id': self.id,
            'up':self.up,
            'down':self.down,
            'multi_down': self.multi_down_list,
            # 'Mix_group_en': self.Mix_group_en,
            'skip':self.skip_list,
            'AM': self.res_AM,
            'Mix_group_de': self.Mix_group_de,
            'psnr_avg':self.psnr_avg,
            'psnr_avg_max':self.psnr_avg_max,
            'spantime':self.spantime,
            'time_train':self.time_train
        }

        return info, arc

    def __str__(self):
        info, _ = self.to_dict()
        return str(info)
