

#  种群需要的参数
params = {
    # 个体参数设置
    "group_list": [1, 2, 3],
    "AM_list": [0, 1],
    "down_num" : 5,
    "up_num" : 3,
    "AM_types":['None', 'Res_SE'],
    "up_type":['nearest_u', 'bilinear_u', 'bicubic_u'],
    "down_type":['stride', 'avg', 'max', 'area_d', 'bilinear_d'],
    # "up_type":['nearest_u', 'bilinear_u', 'area_u', 'subpixel_u'],
    # "down_type":['stride', 'avg', 'max', 'area_d', 'bilinear_d', 'nearest_d'],



    #  分组实验获得的先验知识——优秀组合
    "elite_up":[ 0, 1, 1, 1, 2, 3 ],
    "elite_down":[ 0, 1, 3, 4, 4, 0 ],
    "elite_Mix_group_en":[ [1,2,2,1], [2,2,2,2], [3,2,2,3], [1,1,3,1], [1,1,1,3] ],   
    "elite_Mix_group_de":[ [1,1,2,1], [1,3,1,1], [2,3,2,2], [3,3,1,1], [3,1,3,2] ], 
    "elite_res_AM": [ [0,0,1,0,1], [0,1,0,0,1], [0,1,1,0,1], [0,1,1,1,0], [1,0,0,0,1] ],
    # "elite_skip_list":[ [1,1,0,1,1], [0,0,1,1,0], [0,0,1,1,1], [1,0,1,0,0], [1,1,0,0,1] ],
    "elite_skip_list":[ [1,0,1,0,1], [1,1,0,0,1], [0,1,1,0,1], [0,1,1,1,1], [1,1,1,0,0], [1,1,1,1,1] ],
    "elite_multi_down":[ [0,0,1,0], [0,0,1,1], [1,0,1,0], [1,1,0,0], [1,1,1,1], [1,1,1,0] ],
    


    # 种群参数设置
    'gen':50,               #  进化轮次
    'guided_size':10,       #  初始化知识引导数目
    'pop_size':30,          #  种群个体数目
    'prob_crossover':0.7,   #  个体交叉概率
    'prob_mutate':0.3,      #  子代变异概率
    's':10,                 #  动态参数指导选择父代个数
    't':5,                  #  动态参数指导生成变异个体数目
    'G1':30,                #  多样性探索阶段 0-gen_division1;  收敛阶段 gen_division1-40
    'num_b':3,              #  一阶段环境选择时, 保留最佳个体的数目
    'num_f':8,              #  最终数据集评估时选择的个体数目
}


