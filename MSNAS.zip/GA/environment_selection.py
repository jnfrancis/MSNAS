import numpy as np
import copy
import hashlib

from GA.population import *
from config import *
from Tool.utils import *

def hash_individual(indi_gene):
    """
    为个体的基因序列生成SHA-224哈希值。
    """
    # 将个体的基因序列转换为字符串
    gene_sequence_str = ''.join(map(str, indi_gene))
    
    # 创建一个新的SHA-224哈希对象
    hash_object = hashlib.sha224()
    
    # 用个体的基因序列字符串更新哈希对象
    hash_object.update(gene_sequence_str.encode())
    return hash_object.hexdigest()


#  二元锦标赛选择
def binary_tournament_selection_with_hash(indis, num_selections):
    selected = []
    individuals = indis
    sum_num = len(individuals)
    selected_hashes = set()  # 使用集合存储已选择个体的哈希值

    for _ in range(num_selections):
        # 随机选择两个个体
        idx1 = np.random.randint(sum_num)
        idx2 = np.random.randint(sum_num)
        while idx2 == idx1:
            idx2 = np.random.randint(sum_num)

        # 比较适应度，选择适应度高的个体
        if individuals[idx1].psnr_avg > individuals[idx2].psnr_avg:
            selected_indiv = individuals[idx1]
        else:
            selected_indiv = individuals[idx2]
        # 计算选中个体的哈希值并检查是否已经存在于集合中
        indiv_hash = hash_individual(selected_indiv.gene)

        # 如果哈希值不在已选择的哈希集合中，将其添加到selected列表和哈希集合中
        while indiv_hash in selected_hashes:
            # 如果个体的哈希值已存在，重新选择个体
            idx1 = np.random.randint(sum_num)
            idx2 = np.random.randint(sum_num)
            while idx2 == idx1:
                idx2 = np.random.randint(sum_num)
            
            if individuals[idx1].psnr_avg > individuals[idx2].psnr_avg:
                selected_indiv = individuals[idx1]
            else:
                selected_indiv = individuals[idx2]
            
            indiv_hash = hash_individual(selected_indiv.gene)
        
        selected_hashes.add(indiv_hash)
        selected.append(copy.deepcopy(selected_indiv))

    return selected

#  比较个体基因序列的hash值
def compare_arc(indi1, indi2):
    return hash_individual(indi1.gene) == hash_individual(indi2.gene)

#  二阶段环境选择，0-G1:二元锦标赛+精英获取,  G1-end:排除最差t个个体
def environment_selection(indis, gen_epoch, gen_id):

    #  一阶段环境选择
    if gen_epoch < params['G1']:
        #  二元锦标赛选择下一代
        next_generation = binary_tournament_selection_with_hash(indis, params['pop_size'])
        
        # 获取整个 self.indis 中最好的num_b个个体
        best_num_indis = sorted(indis, key=lambda indi: indi.psnr_avg, reverse=True)[:params['num_b']]

        # 为每个最优个体确保它们在下一代种群中
        for best_ind in best_num_indis:
            if not any(compare_arc(best_ind, next_ind) for next_ind in next_generation):
                # 对下一代种群按适应度排序, 升序
                next_generation.sort(key=lambda indi: indi.psnr_avg)
                
                # 用最优个体替换最差的个体
                worst_of_next = next_generation[0]
                next_generation.remove(worst_of_next)
                next_generation.append(best_ind)
        
        # 所有个体重新编号
        indi_id=1
        for indi in next_generation:
            indi.id="%02d%02d"%(gen_id,indi_id)
            indi_id+=1

        return next_generation
    
    #  第二阶段
    else:
        #  淘汰最差的t个个体
        indis.sort(key=lambda indi: indi.psnr_avg, reverse=True)
        for _ in range(params['t']):
            indis.pop(-1)

        # 所有个体重新编号
        indi_id=1
        for indi in indis:
            indi.id="%02d%02d"%(gen_id,indi_id)
            indi_id+=1

        return indis