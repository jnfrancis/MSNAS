import os
import argparse
import glob
import json

from DIP import config_parser

from DIP.utils.common_utils import *
from DIP.utils.denoising_utils import *
from DIP.utils.denosing_shiyan import *
from DIP.final_arc import *

from config import *



def read_dataset_file_list(eval_data):
    dataset_dir = "./DIP/testset/%s/" % eval_data
    file_list1 = glob.glob(dataset_dir + "*.tif")
    file_list2 = glob.glob(dataset_dir + "*.png")
    file_list3 = glob.glob(dataset_dir + "*.JPG")
    file_list = file_list1 + file_list2 + file_list3
    return file_list

def save_info(stat, save_path):
    path = './DIP/component_test/new/' + save_path
    with open(path, 'a') as file:
        for key, value in stat.items():
            file.write(f"{key}: {value}\n")
        file.write('\n')

def file_test(args):
    file_list = read_dataset_file_list(args.eval_data)
    file_list = sorted(file_list)
    stat_list = []
    stat_max_list = []
    stat_dict = {} 

    start = time.time()
    stat_dict['info'] = args.net_type + '_' + ''.join(map(str, args.res_AM_list)) + '_' + str(args.sigma)
    for file in file_list:
        print("[*] process image file : %s"  % file)
        stat, stat_max = image_restorazation(file, args)

        base_name = os.path.splitext(os.path.basename(file))[0]
        stat_dict[base_name] = stat
        max_name = base_name + 'max_psnr'
        stat_dict[max_name] = stat_max
        print(f"Image: {base_name}, Stat: {stat}")
        print(f"Image: {base_name}, Stat_Max: {stat_max}")

        stat_list.append(stat)
        stat_max_list.append(stat_max)

    average_stat = sum(stat_list) / len(stat_list) if stat_list else None
    average_stat_max = sum(stat_max_list) / len(stat_max_list) if stat_max_list else None
    stat_dict['average_PSNR'] = average_stat
    stat_dict['average_PSNR_MAX'] = average_stat_max
    psnr_avg, psnr_avg_max = average_stat, average_stat_max

    end = time.time()
    t = end-start
    stat_dict['实验耗时'] = t

    # 打印或进一步处理平均值
    print(f"Average stat value: {average_stat}")
    print(f"Average stat MAX value: {average_stat_max}")
    save_path =  args.eval_data + '/' + args.net_type + '_result.txt'
    save_info(stat_dict, save_path)
    print("experiment done")


def main():

    # For REPRODUCIBILITY
    print("[*] reproduce mode On")
    torch.manual_seed(0)
    np.random.seed(0)


    if torch.cuda.is_available():
        # CUDA可用
        dtype = torch.cuda.FloatTensor  # 在GPU上使用点数
        device = torch.device("cuda:0")  # 指定GPU编号为3
        print(f"CUDA is available, running on {device}.")
    else:
        raise EnvironmentError("CUDA is not available. Please check your CUDA installation.")
    

    args = config_parser.main_parser()
    args.device = device
    args.task_type = 'denoising'  # 设置子任务为去噪
    args.sigma = 25  # 设置sigma为25
    args.force_steplr = True
    

    args.dip_type = 'eSURE_uniform'
    args.lr = 0.1


    args.reg_noise_std = 1/20
    args.epoch = 3000
    
    
    file = "./DIP/testset/CSet9/image_F16_512rgb.png"
    
    net_list = ['s2s_multi_skip_mix_de_am', 's2s_up_down', 's2s_res_SE', 's2s_skip_concat_neibor', 's2s_down_fc', 's2s_Mix_2_5']  # 's2s'

    file_list = ['CSet9', 'Set12', 'CBSD68', 'BSD68']

    sigma_list = [15, 25, 50]


    args.up = params['up_type'][1]
    args.down = params['down_type'][4]
    args.down_concat_list = [1, 0, 0, 1]
    args.skip_concat_list = [0, 0, 1, 0, 1]
    args.res_AM_list = [1, 0, 0, 0, 1]
    args.group_de_list = [1, 1, 2, 1]

    args.eval_data = 'CSet9'
    args.net_type = 's2s_up_down'

    

    for args.sigma in sigma_list:
        np.random.seed(0)  # 在每次循环开始前重新设置种子
        torch.manual_seed(0)
        
        file_test(args)

    exit()

    args.sigma = 50
    for i in range(5):
        np.random.seed(0)  # 在每次循环开始前重新设置种子
        torch.manual_seed(0)
        
        file_test(args)
    

    args.sigma = 25
    for i in range(5):
        np.random.seed(0)  # 在每次循环开始前重新设置种子
        torch.manual_seed(0)
        
        file_test(args)
    
    args.sigma = 15
    for i in range(3):
        np.random.seed(0)  # 在每次循环开始前重新设置种子
        torch.manual_seed(0)
        
        file_test(args)
    


 
    # for i in range(2):
    #     for d in range(4):
    #         args.eval_data = file_list[d]
    #         args.gray = False
    #         if args.eval_data == 'Set12' or args.eval_data == 'BSD68':
    #             args.gray = True
    #         for s in range(3):
    #             args.sigma = sigma_list[s]
    #             for j in range(6):
    #                 np.random.seed(0)  # 在每次循环开始前重新设置种子
    #                 torch.manual_seed(0)
    #                 args.net_type = net_list[j]

    #                 args.path1 = (
    #                     str(args.up) + '_' + str(args.down) + '_multi_down_' +
    #                     ''.join(map(str, args.down_concat_list)) + '_skip_' +
    #                     ''.join(map(str, args.skip_concat_list)) + '_mix_de_' +
    #                     ''.join(map(str, args.group_de_list)) + '_res_am_' +
    #                     ''.join(map(str, args.res_AM_list)) + '--sigma--' + str(args.sigma)
    #                 )
    #                 file_test(args)

                    



# nohup python -u ablation_experiment.py > ablation_experiment.log 2>&1 &




if __name__ == "__main__":
    main()