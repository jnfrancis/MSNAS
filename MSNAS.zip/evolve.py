
import random
import numpy as np

from GA.population import *
from GA.crossover_and_mutation import *
from GA.dynamic_mutation import *
from GA.environment_selection import *


from config import *
from Tool.utils import *
from Tool.Log import *
from DIP.shiyan import *

#  初始种群适应度评估函数
def fitness_evaluate_init(indis):
    for indi in indis:
        indi.psnr_avg, indi.psnr_avg_max, indi.time_train = file_shiyan(indi, "cuda:3")

#  避免偶然性, 对优秀个体的值进行重新评估
def fitness_evaluate_update(indi):
    indi.psnr_avg, indi.psnr_avg_max, indi.time_train = file_shiyan(indi, "cuda:3")
    indi.value_life = 0   # 个体值已更新, 值在种群中存在时间清零

#  Aging Evolution思想, 避免偶然性情况
def fitness_update(indis, t):
    all_indis_sorted  = sorted(indis, key=lambda indi: indi.psnr_avg, reverse=True)
    update_fitness = {} # 记录已更新的个体的值
   
    best_t_indis = all_indis_sorted [:t]
    for indi in best_t_indis:
        if indi.value_life >= 3:
            indi_hash = hash_individual(indi.gene)
            if indi_hash in update_fitness: # 如果前t个个体中有相同基因个体已经重新评估过, 就直接继承
                indi.psnr_avg, indi.psnr_avg_max, indi.time_train, indi.spantime, indi.value_life = update_fitness[indi_hash]
            else:
                fitness_evaluate_update(indi)
                indi_hash = hash_individual(indi.gene)
                update_fitness[indi_hash] = (indi.psnr_avg, indi.psnr_avg_max, indi.time_train, indi.spantime, indi.value_life)
    #  前t个个体达到寿命重新评估条件评估后, 更新种群中具有相同基因的个体
    for indi in all_indis_sorted[t:]:
        indi_hash = hash_individual(indi.gene)
        if indi_hash in update_fitness:
                indi.psnr_avg, indi.psnr_avg_max, indi.time_train, indi.spantime, indi.value_life = update_fitness[indi_hash]   
    


#  适应度评估, 若子代个体基因与父代相同, 直接继承父代训练结果
def fitness_evaluate(popu, offspring):
    # 创建一个字典，键为个体哈希值，值为个体适应度信息
    count = 0
    popu_fitness = {}
    for individual in popu:
        individual_hash = hash_individual(individual.gene)
        if individual_hash not in popu_fitness: #  只针对二阶段可能存在出现相同基因个体的情况, 避免重复操作
            popu_fitness[individual_hash] = (individual.psnr_avg, individual.psnr_avg_max, individual.time_train, individual.spantime, individual.value_life)

    for indi in offspring:
        # 生成当前个体的哈希值
        indi_hash = hash_individual(indi.gene)
        
        # 检查哈希值是否已在字典中
        if indi_hash in popu_fitness:
            # 如果存在，直接使用已有的适应度值
            indi.psnr_avg, indi.psnr_avg_max, indi.time_train, indi.spantime, indi.value_life = popu_fitness[indi_hash]
            count += 1
        else:
            # 如果不存在，进行训练并获取适应度值
            indi.psnr_avg, indi.psnr_avg_max, indi.time_train = file_shiyan(indi, "cuda:3")
            indi.value_life = 0  # 个体值已更新, 值在种群中存在时间清零
            # 将训练好的结果添加进字典, 若有重复架构可直接继承, 无需再训练
            indi_hash = hash_individual(indi.gene)
            popu_fitness[indi_hash] = (indi.psnr_avg, indi.psnr_avg_max, indi.time_train, indi.spantime, indi.value_life)
    return count



#  最终种群最优t个个体大数据集适应度评估
def fitness_evaluate_max(indis):
    for indi in indis:
        indi.psnr_avg, indi.psnr_avg_max, indi.time_train = file_shiyan_max(indi, "cuda:3")

class Evolve():
    def __init__(self):
        self.params = params
        self.population = None
        self.log = Log()
        self.total_gen = params['gen']
        self.G1 = params['G1']
        self.size = params['pop_size']
        self.t = params['t']
        
        
    
    def do_evolve(self):
        start = time.time()
        self.log.info("-"*50+"[种群初始化]"+"-"*50+"\n")
        self.population = population(params, 1)
        self.population.initialize()
        indis = self.population.individuals

        self.log.info("-"*50+"[初始种群适应度评估]"+"-"*50+"\n")
        #  适应度评估
        fitness_evaluate_init(indis)
        

        #  保存初始化种群
        save_popu_initial(self.population.individuals)
        self.log.info("-"*50+"[种群开始进化]"+"-"*50+"\n")

        # 种群进化
        for gen in range(self.total_gen):
            indis = self.population.individuals
            self.log.info("*"*30+"当前种群位于第{}代进化".format(gen+1)+"*"*30)


            self.log.info("*"*30+"第{}代进化前优秀个体基于寿命重新评估".format(gen+1)+"*"*30+"\n")
            fitness_update(indis, self.t)
        
            # 二阶段选择GA操作
            if gen < self.G1:
                GA_OP = CrossoverAndMutation(indis, gen+1, params['prob_crossover'], params['prob_mutate'], self.log)
            else:
                GA_OP = Dynamic_Mutation(indis, gen+1, self.log)
            
            offspring = GA_OP.process()
            self.population.gen_id+=1


            self.log.info("*"*30+"子代种群适应度评估"+"*"*30+"\n")
            # 子代适应度评估
            unchanged_num = fitness_evaluate(indis, offspring)
            if unchanged_num > 0:
                self.log.info("子代种群直接继承未训练个体数目:{}".format(unchanged_num) + "\n")

            
            self.population.add_offsprings_to_parents(offspring)
            self.population.updata_indi_id()
            # 环境选择
            next_generation = environment_selection(indis, gen, self.population.gen_id)
            self.population.individuals = next_generation
            # 更新种群中个体的寿命
            self.population.cal_indi_spantime()

            
            #  保存演化过程中的种群
            save_popu_evolve(self.population.individuals, gen+1)
            #  保存当前种群中的最佳个体
            save_indi_best_evolve(self.population.individuals)

            
        
        self.log.info("-"*50+"[种群进化结束]"+"-"*50+"\n")
        #  保存最后一代种群
        save_popu_final(self.population.individuals)

        #  最后一代种群中, 多方面选择部分个体进行大数据集评估, 来选择效果更好更有泛化性的个体
        final_selected_indis = []
        selected_hashes = set()
        # 第一步, 按psnr_avg降序排序, 选择不重复架构的个体直到达到t个
        final_indis_sorted_1 = sorted(self.population.individuals, key=lambda indi: indi.psnr_avg, reverse=True)
        for indi in final_indis_sorted_1:
            indi_hash = hash_individual(indi.gene)
            if indi_hash not in selected_hashes:
                final_selected_indis.append(indi)
                selected_hashes.add(indi_hash)
                # if len(final_selected_indis) >= params['t']:
                if len(final_selected_indis) >= params['num_f']:
                    break
        #  第二步, 按psnr_avg_max降序排序, 前t个个体中选择未被选中的
        # final_indis_sorted_2 = sorted(self.population.individuals, key=lambda indi: indi.psnr_avg_max, reverse=True)
        # best_t_indis = final_indis_sorted_2[:params['t']]
        # for indi in best_t_indis:
        #     indi_hash = hash_individual(indi.gene)
        #     if indi_hash not in selected_hashes:
        #         final_selected_indis.append(indi)
        #         selected_hashes.add(indi_hash)
        #  第三步, 随机选择3个未被选中的个体, 最后增加一点随机性



        self.log.info("-"*50+"最终种群选择个体进行大数据集适应度评估"+"-"*50+"\n")
        #  最终选择的个体进行数据集评估
        fitness_evaluate_max(final_selected_indis)

        #  保存最终种群中选择的个体数据集评估的结果
        save_indis_selected_final(final_selected_indis)

        #  选择最后的最优个体
        all_indis = sorted(final_selected_indis, key=lambda indi: indi.psnr_avg, reverse=True)
        best_t_indi = all_indis[0]

        #   保存最优个体
        save_best_indi_final(best_t_indi)
        
        self.log.info("-"*50+"[整个演化过程结束]"+"-"*50+"\n")
        end = time.time()
        self.log.info("演化搜索总运行时间：%.2f 秒\n"%(end-start))


if __name__=="__main__":
    evolve=Evolve()
    evolve.do_evolve()

# nohup python -u evolve.py > evolve.log 2>&1 &