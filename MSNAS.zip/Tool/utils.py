

def save_indis_after_crossover(indis, gen_no):
    path = './result/GA/crossover/crossover_%02d.txt'%(gen_no)
    
    with open(path, 'w') as file:
        for indi in indis:
            _, arc = indi.to_dict()
            file.write(str(arc) + "\n\n")
          

def save_indis_after_mutation(indis, gen_no):
    path = './result/GA/mutation/mutation_%02d.txt'%(gen_no)
    with open(path, 'w') as file:
        for indi in indis:
            _, arc = indi.to_dict()
            file.write(str(arc) + "\n\n")



def save_indis(indis, path):
    with open(path, 'w') as file:
        for indi in indis:
            file.write(str(indi) + "\n\n")

def save_arc(indis, path):
    with open(path, 'w') as file:
        for indi in indis:
            _, arc = indi.to_dict()
            file.write(str(arc) + "\n\n")


#  保存初始种群
def save_popu_initial(indis):
    path1 = './result/initial_population/initial_population_info.txt'
    path2 = './result/initial_population/initial_population_arc.txt'
    save_indis(indis, path1)
    save_arc(indis, path2)

#  保存演化中的种群
def save_popu_evolve(indis, gen_no):
    path1 = './result/evolutionary_population/info/evolve_info_%02d.txt'%(gen_no)
    path2 = './result/evolutionary_population/arc/evolve_arc_%02d.txt'%(gen_no)
    save_indis(indis, path1)
    save_arc(indis, path2)

#  保存演化中的每一代最优的t个个体
def save_indi_best_evolve(indis):
    path1 = './result/evolutionary_population/best/evolve_best_info.txt'
    path2 = './result/evolutionary_population/best/evolve_best_arc.txt'
    best_indi = indis[0]
    for indi in indis[1:]:
        if indi.psnr_avg > best_indi.psnr_avg:
            best_indi=indi
    with open(path1, 'a') as file:
        file.write(str(best_indi) + "\n\n")
    with open(path2, 'a') as file:
        _, arc = best_indi.to_dict()
        file.write(str(arc) + "\n\n")


#  保存最后一代种群
def save_popu_final(indis):
    path1 = './result/final_population/final_pop_info.txt'
    path2 = './result/final_population/final_pop_arc.txt'
    save_indis(indis, path1)
    save_arc(indis, path2)


#  保存最终种群中选择进行大数据集训练的个体
def save_indis_selected_final(indis):
    path1 = './result/final_selected_indis/final_selected_info.txt'
    path2 = './result/final_selected_indis/final_selected_arc.txt'
    save_indis(indis, path1)
    save_arc(indis, path2)

#  保存最终结果
def save_best_indi_final(indi):
    path1 = './result/final_indi/final_info.txt'
    path2 = './result/final_indi/final_arc.txt'
    with open(path1, 'w') as file:
        file.write(str(indi) + "\n\n")
    with open(path2, 'w') as file:
        _, arc = indi.to_dict()
        file.write(str(arc) + "\n\n")


def save_indi_ha(indis):
    path = './ha/info.txt'
    
    with open(path, 'w') as file:
        for indi in indis:
            file.write(str(indi) + "\n\n")

def save_arc_ha(indis):
    path = './ha/arc.txt'
    
    with open(path, 'w') as file:
        for indi in indis:
            _, arc = indi.to_dict()
            file.write(str(arc) + "\n\n")
