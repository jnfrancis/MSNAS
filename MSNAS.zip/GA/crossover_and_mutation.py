import random
import numpy as np
import copy

from config import *
from Tool.utils import *

def Similarity_cal(gene_a, gene_b):
    """
    计算两个个体基因序列之间的汉明距离，并以此计算两序列之间的相似度
    """
    if len(gene_a) != len(gene_b):
        raise ValueError("两个体基因必须是相同基因长度！")
    
    ham_dis = sum(1 for a, b in zip(gene_a, gene_b) if a != b)
    diff = ham_dis / len(gene_a)
    return diff

class CrossoverAndMutation(object):
    def __init__(self, individuals, gen_epoch, prob_crossover, prob_mutation, _log):
        self.prob_crossover = prob_crossover
        self.prob_mutation = prob_mutation
        self.individuals = individuals
        self.log = _log
        self.gen_epoch = gen_epoch
        self.offspring = []

    def process(self):
        crossover = Crossover(self.individuals, self.prob_crossover, self.log)
        offspring = crossover.do_crossover()
        self.offspring = offspring

        for index,indi in enumerate(self.offspring):
            indi.id = "%02d%02d"%(self.gen_epoch, params["pop_size"]+index+1)

        
        save_indis_after_crossover(self.offspring, self.gen_epoch)

        mutation = Mutation(self.offspring, self.prob_mutation, self.log)
        mutation.do_mutation()
        save_indis_after_mutation(self.offspring, self.gen_epoch)

        return self.offspring




#  两个体随机单元进行交换
class Crossover(object):
    def __init__(self, individuals, prob_, log):
        self.individuals = individuals
        self.prob = prob_
        self.log = log
        
        
    def _choose_one_parent(self):
        count_ = len(self.individuals)
        idx1 = int(np.floor(np.random.random()*count_))
        idx2 = int(np.floor(np.random.random()*count_))
        while idx2 == idx1:
            idx2 = int(np.floor(np.random.random()*count_))

        if self.individuals[idx1].psnr_avg > self.individuals[idx2].psnr_avg:
            return idx1
        else:
            return idx2
        
    def _choose_two_diff_parents(self):
        for _ in range(10):
            idx1, idx2 = self.select_two_individuals()  # 假设这是一个随机选择的方法
            if Similarity_cal(self.individuals[idx1].gene, self.individuals[idx2].gene) > 0.4:
                break
        
        # idx1 = self._choose_one_parent()
        # idx2 = self._choose_one_parent()
        #  进行父代选择时, 通过计算两个体基因序列相似度, 避免选择过分相似的个体
        # while idx2 == idx1 or Similarity_cal(self.individuals[idx1].gene, self.individuals[idx2].gene) < 0.4:
        #     idx2 = self._choose_one_parent()

        assert idx1 < len(self.individuals)
        assert idx2 < len(self.individuals)
        return idx1, idx2
    
    def do_crossover(self):
        _stat_param = {'offspring_new':0, 'offspring_from_parent':0}
        new_offspring_list = []
        for _ in range(len(self.individuals)//2):
            ind1, ind2 = self._choose_two_diff_parents()
            parent1, parent2 = copy.deepcopy(self.individuals[ind1]), copy.deepcopy(self.individuals[ind2])
            p_ = random.random()
            if p_ < self.prob:
                # 结构化交叉
                _stat_param['offspring_new'] += 2

                # 采样结构
                parent1.down, parent2.down = parent2.down, parent1.down
                self.log.info("进行下采样交叉")

                # 编码器模块结构交叉
                en_num_layer = random.randint(0, 3)
                parent1.multi_down_list[en_num_layer], parent2.multi_down_list[en_num_layer] = parent2.multi_down_list[en_num_layer], parent1.multi_down_list[en_num_layer]
                self.log.info("第%d层多尺度结构交叉 "%(en_num_layer+1))


                # 解码器模块结构交叉
                de_num_layer = random.randint(0, 4)
                parent1.skip_list[de_num_layer], parent2.skip_list[de_num_layer] = parent2.skip_list[de_num_layer], parent1.skip_list[de_num_layer]    
                de_num_layer = random.randint(0, 4)                
                parent1.res_AM[de_num_layer], parent2.res_AM[de_num_layer] = parent2.res_AM[de_num_layer], parent1.res_AM[de_num_layer]
                mix_de_num_layer = random.randint(0, 3)
                parent1.Mix_group_de[mix_de_num_layer], parent2.Mix_group_de[mix_de_num_layer] = parent2.Mix_group_de[mix_de_num_layer], parent1.Mix_group_de[mix_de_num_layer]
                self.log.info("第%d层邻域连接和注意力结构交叉 第%d层混合深度卷积组数交叉"%(de_num_layer, mix_de_num_layer))

                parent1.update_gene()
                parent2.update_gene()
                offspring1, offspring2 = parent1, parent2
                offspring1.reset_attrib()
                offspring2.reset_attrib()
                new_offspring_list.append(offspring1)
                new_offspring_list.append(offspring2)
            else:
                _stat_param['offspring_from_parent'] += 2
                new_offspring_list.append(parent1)
                new_offspring_list.append(parent2)

        self.log.info('交叉-%d 交叉产生新个体数目:%d, 未交叉个体数目:%d'%(len(new_offspring_list), _stat_param['offspring_new'],_stat_param['offspring_from_parent']))
        return new_offspring_list


class Mutation(object):
    def __init__(self, individuals, prob_, _log):
        self.individuals = individuals
        self.prob = prob_
        self.log = _log
    
    def do_mutation(self):
        _stat_param = {'offspring_new':0, 'offspring_from_parent':0}
        for indi in self.individuals:
            p_ = random.random()
            if p_ < self.prob:
                #  结构化变异
                _stat_param['offspring_new'] += 1
                
                #  下采样结构变异
                down_list = [n for n in list(range(indi.down_num)) if n != indi.down]
                indi.down = random.choice(down_list)
                self.log.info("个体:%s 进行下采样变异"%(indi.id))  

                #  编码器部分结构变异
                en_num_layer = random.randint(0, 3)  #  具体单元层数
                indi.multi_down_list[en_num_layer] = 1 if indi.multi_down_list[en_num_layer] == 0 else 0
                self.log.info("个体:%s 第%d层编码器单元变异 "%(indi.id, en_num_layer+1))  


                #  解码器部分结构变异
                de_num_layer = random.randint(0, 4)  #  具体单元层数
                indi.skip_list[de_num_layer] = 1 if indi.skip_list[de_num_layer] == 0 else 0
                de_num_layer = random.randint(0, 4)  #  具体单元层数           
                indi.res_AM[de_num_layer] = 1 if indi.res_AM[de_num_layer] == 0 else 0
                mix_de_num_layer = random.randint(0, 3)  #  mix组数变异具体单元层数
                group_values_m = [v for v in indi.group_values if v != indi.Mix_group_de[mix_de_num_layer]]
                indi.Mix_group_de[mix_de_num_layer] = random.choice(group_values_m)   
                self.log.info("个体:%s 解码器中： 第%d层邻域连接和注意力结构变异 第%d层混合深度卷积组数变异"%(indi.id, de_num_layer, mix_de_num_layer))
                
                
                indi.reset_attrib()
                indi.update_gene()
            else:
                _stat_param['offspring_from_parent'] += 1
        self.log.info('变异 变异个体数目:%d, 未变异个体数目:%d' %(_stat_param['offspring_new'],  _stat_param['offspring_from_parent']))


#  两个体基因进行多点交叉
# class Crossover(object):
#     def __init__(self, individuals, prob_, log):
#         self.individuals = individuals
#         self.prob = prob_
#         self.log = log