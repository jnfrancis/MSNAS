import random
import numpy as np
import copy

from config import *
from Tool.utils import *

#  计算当前种群中最优t个个体中各个参数取值的频次
def count_frequencies(best_t_indis):

    # 初始化不同模式的频率字典
    # freq_up_mode = {i: 0 for i in range(params['up_num'])}
    freq_down_mode = {i: 0 for i in range(params['down_num'])}
    freq_multi_down_list = [{i: 0 for i in range(2)} for _ in range(4)]   
    freq_skip_list = [{i: 0 for i in range(2)} for _ in range(5)]             
    freq_Mix_de_list = [{i: 0 for i in range(1, 4)} for _ in range(4)]       
    freq_Res_AM_list = [{i: 0 for i in range(2)} for _ in range(5)]       
    
    for indi in best_t_indis:
        # freq_up_mode[indi.up] += 1
        freq_down_mode[indi.down] +=1
        for pos, multi_down in enumerate(indi.multi_down_list):
            freq_multi_down_list[pos][multi_down] += 1
        for pos, skip in enumerate(indi.skip_list):
            freq_skip_list[pos][skip] += 1
        for pos, group_de in enumerate(indi.Mix_group_de):
            freq_Mix_de_list[pos][group_de] += 1
        for pos, res_AM in enumerate(indi.res_AM):
            freq_Res_AM_list[pos][res_AM] += 1
        
    # return freq_up_mode, freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list
    return freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list



#  根据计算的频次更新权重列表
# def update_weights(freq_up_mode, freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list):
def update_weights(freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list):
    # 初始化权重列表为键值对形式
    weight_up_mode = {i: 1 for i in range(params['up_num'])}
    weight_down_mode = {i: 1 for i in range(params['down_num'])}
    weight_multi_down_list = [{i: 1 for i in range(2)} for _ in range(4)]
    weight_skip_list = [{i: 1 for i in range(2)} for _ in range(5)]
    weight_Mix_de_list = [{i: 1 for i in range(1, 4)} for _ in range(4)]
    weight_Res_AM_list = [{i: 1 for i in range(2)} for _ in range(5)]

    # 计算并更新权重
    # max_up = max(freq_up_mode.values())
    # for key, value in freq_up_mode.items():
    #     if value == max_up:
    #         weight_up_mode[key] += 1

    max_down = max(freq_down_mode.values())
    for key, value in freq_down_mode.items():
        if value == max_down:
            weight_down_mode[key] += 1

    for i in range(4):
        max_multi_down = max(freq_multi_down_list[i].values())
        for key, value in freq_multi_down_list[i].items():
            if value == max_multi_down:
                weight_multi_down_list[i][key] += 1

    for i in range(5):
        max_skip = max(freq_skip_list[i].values())
        for key, value in freq_skip_list[i].items():
            if value == max_skip:
                weight_skip_list[i][key] += 1


    for i in range(4):
        max_Mix_de = max(freq_Mix_de_list[i].values())
        for key, value in freq_Mix_de_list[i].items():
            if value == max_Mix_de:
                weight_Mix_de_list[i][key] += 1

    for i in range(5):
        max_Res_AM = max(freq_Res_AM_list[i].values())
        for key, value in freq_Res_AM_list[i].items():
            if value == max_Res_AM:
                weight_Res_AM_list[i][key] += 1

    # return weight_up_mode, weight_down_mode, weight_multi_down_list, weight_skip_list, weight_Mix_de_list, weight_Res_AM_list
    return weight_down_mode, weight_multi_down_list, weight_skip_list, weight_Mix_de_list, weight_Res_AM_list



#  根据权重轮盘赌获取
def weighted_choice(weights):
    sum_w = sum(weights.values())
    u = np.random.rand()*sum_w
    sum_ = 0
    for k, w in sorted(weights.items()):
        sum_ += w
        if sum_ >= u:
            return k
    assert False, "Shouldn't get here"


class Dynamic_Mutation():
    def __init__(self, individuals, gen_epoch, log):
        self.log = log
        self.indis = individuals
        self.s = params['s']
        self.t = params['t']
        self.gen_epoch = gen_epoch
    
    def process(self):
        # 获取整个 self.indis 中最好的 t 个个体
        all_indis_sorted  = sorted(self.indis, key=lambda indi: indi.psnr_avg, reverse=True)
        best_t_indis = all_indis_sorted [:self.t]

        # 排除最好的5个 
        remaining_indis = all_indis_sorted [self.t:]
        # 1.随机选取s个父代个体
        s_random_indexs=np.random.choice(list(range(len(remaining_indis))), self.s, replace=False)
        s_indis=[self.indis[i] for i in s_random_indexs]
        # 2.从s个父代个体中选取t个适应度最优的个体
        s_indis.sort(key=lambda indi:indi.psnr_avg, reverse=True)
        t_selected_inids = [copy.deepcopy(s_indis[i]) for i in range(self.t)]


        #  计算最优t个个体各部分的频次，并更新权重
        # freq_up_mode, freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list = count_frequencies(best_t_indis)
        # weight_up_mode, weight_down_mode, weight_multi_down_list, weight_skip_list, weight_Mix_de_list, weight_Res_AM_list = update_weights(freq_up_mode, freq_down_mode, freq_multi_down_list, 
        #                                                                                                                                     freq_skip_list, freq_Mix_de_list, freq_Res_AM_list)
        freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list = count_frequencies(best_t_indis)
        weight_down_mode, weight_multi_down_list, weight_skip_list, weight_Mix_de_list, weight_Res_AM_list = update_weights(freq_down_mode, freq_multi_down_list, freq_skip_list, freq_Mix_de_list, freq_Res_AM_list)




        #  权重指导变异
        new_offspring_list = []
        for indi in t_selected_inids:
            
            #  采样部分变异
            sample_type =  random.choice([0, 1])
            # if sample_type == 0:    #  上采样
            #     indi.up = weighted_choice(weight_up_mode)
            #     self.log.info("上采样变异")  
            # elif sample_type == 1:  #  下采样
            indi.down = weighted_choice(weight_down_mode)
            self.log.info("下采样变异")  

            #  编码器部分结构变异
            num_layer = random.randint(0, 3)  #  具体单元层数
            indi.multi_down_list[num_layer] = weighted_choice(weight_multi_down_list[num_layer])
            self.log.info("编码器部分： 第%d层多尺度输入结构变异"%(num_layer+1))


            #  解码器部分结构变异
            num_layer = random.randint(0, 4)  #  具体单元层数
            indi.skip_list[num_layer] = weighted_choice(weight_skip_list[num_layer])    
            num_layer = random.randint(0, 4)  #  具体单元层数
            indi.res_AM[num_layer] = weighted_choice(weight_Res_AM_list[num_layer])
            mix_num_layer = random.randint(0, 3)   #  mix组数变异具体单元层数
            indi.Mix_group_de[mix_num_layer] = weighted_choice(weight_Mix_de_list[mix_num_layer])    
            self.log.info("解码器部分： 第%d层邻域连接和注意力结构变异 第%d层混合深度卷积组数变异 "%(num_layer, mix_num_layer))   
            
            indi.reset_attrib()
            indi.update_gene()
            new_offspring_list.append(indi)


        #  种群更新id
        for index, indi in enumerate(new_offspring_list):
            indi.id = "%02d%02d"%(self.gen_epoch, params["pop_size"]+index+1)


        return new_offspring_list
    

